const config = {
  nombre: 'Karen Angélica Flórez Saboya',
  mes: 'Junio 2026',
  diploma: 'Karen Angelica Florez Saboya.png'
};

// Actualiza la plantilla desde un único punto de configuración.
(function () {
  var diplomaPath = 'assets/diplomas/' + config.diploma;
  var diplomaAlt = 'Diploma de reconocimiento de ' + config.nombre + ' - ' + config.mes;

  function setText(id, value) {
    var element = document.getElementById(id);
    if (element) element.textContent = value;
  }

  setText('advisorName', config.nombre);
  setText('recognitionMonth', config.mes);

  var diplomaImage = document.getElementById('diplomaImage');
  if (diplomaImage) {
    diplomaImage.src = diplomaPath;
    diplomaImage.alt = diplomaAlt;
  }

  var downloadButton = document.getElementById('downloadDiploma');
  if (downloadButton) {
    downloadButton.href = diplomaPath;
    downloadButton.download = config.diploma;
    downloadButton.setAttribute('aria-label', 'Descargar diploma de ' + config.nombre);
  }
}());
