# Diploma de Reconocimiento

Página web estática que muestra un diploma de reconocimiento personalizado, generado desde un único punto de configuración (`script.js`).

## Estructura del proyecto

```
diploma-site/
├── index.html
├── style.css
├── script.js
└── assets/
    └── diplomas/
        └── Karen Angelica Florez Saboya.png   ← agrega aquí la imagen del diploma
```

## Cómo cambiar el diploma para otra persona

Edita solo el objeto `config` en `script.js`:

```js
const config = {
  nombre: 'Nombre de la persona',
  mes: 'Mes Año',
  diploma: 'nombre-del-archivo.png'
};
```

Y coloca la imagen correspondiente dentro de `assets/diplomas/`.

## Cómo publicarlo en GitHub Pages

1. Crea un repositorio nuevo en GitHub (público, para poder usar Pages gratis).
2. Sube todos los archivos de esta carpeta manteniendo la estructura (incluida la carpeta `assets/diplomas/` con la imagen real del diploma, ya que no está incluida aquí).
3. Ve a **Settings → Pages**.
4. En "Source", selecciona la rama `main` y la carpeta `/root`.
5. Guarda. GitHub te dará una URL similar a:
   ```
   https://tu-usuario.github.io/nombre-del-repo/
   ```
6. Espera 1-2 minutos y abre el link.

## Notas

- Recuerda subir la imagen real del diploma a `assets/diplomas/` con el mismo nombre que pusiste en `config.diploma` (respetando mayúsculas, acentos y espacios).
- Si el nombre del archivo tiene espacios o tildes, funciona en GitHub Pages, pero es buena práctica evitarlos (por ejemplo, usar `karen-angelica-florez-saboya.png`) para prevenir problemas en algunos navegadores o al compartir el link directo a la imagen.
